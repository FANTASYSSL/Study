package com.wch.sessionTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootSessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootSessionApplication.class, args);
	}
	
	
}
