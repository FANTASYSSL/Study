package com.wch.sessionTest.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestSession {

	@RequestMapping("/test")
	public Map<String, Object> getSession(HttpServletRequest request){
		Map<String, Object> map = new HashMap<>();
		String sessionId = request.getSession().getId();
		int serverPort = request.getServerPort();
		map.put("sessionId",sessionId);
		map.put("serverPort", serverPort);
		return map;
	}
	
	
}
